import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.Slider;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.Duration;

import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class MusicPlayer extends Application {
    private List<String> playlist;
    private int currentSongIndex;
    private MediaPlayer mediaPlayer;
    private ListView<String> playlistView;
    private Slider volumeSlider;

    @Override
    public void start(Stage primaryStage) {
        playlist = new ArrayList<>();
        currentSongIndex = -1;

        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #333333;");

        // Header with logo
        HBox header = new HBox();
        header.setStyle("-fx-background-color: #666666; -fx-padding: 10;");
        ImageView logo = new ImageView(new Image("file:logo.png"));
        logo.setFitWidth(100);
        logo.setPreserveRatio(true);
        header.getChildren().add(logo);
        root.setTop(header);

        playlistView = new ListView<>();
        playlistView.setStyle("-fx-background-color: #666666; -fx-text-fill: white;");
        root.setCenter(playlistView);

        HBox controls = new HBox();
        controls.setStyle("-fx-background-color: #666666; -fx-padding: 10;");
        Button addButton = new Button("Add Song");
        addButton.setStyle("-fx-background-color: #00cc00; -fx-text-fill: white;");
        addButton.setOnAction(e -> addSong());
        Button playButton = new Button("Play");
        playButton.setStyle("-fx-background-color: #0099ff; -fx-text-fill: white;");
        playButton.setOnAction(e -> play());
        Button stopButton = new Button("Stop");
        stopButton.setStyle("-fx-background-color: #ff3333; -fx-text-fill: white;");
        stopButton.setOnAction(e -> stop());
        volumeSlider = new Slider(0, 100, 50);
        volumeSlider.setStyle("-fx-background-color: #666666; -fx-control-inner-background: #333333;");
        volumeSlider.valueProperty().addListener((obs, oldValue, newValue) -> setVolume(newValue.doubleValue()));

        controls.getChildren().addAll(addButton, playButton, stopButton, volumeSlider);
        root.setBottom(controls);

        Scene scene = new Scene(root, 400, 400);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Music Player");
        primaryStage.show();

        // Add animation to the play button
        Timeline timeline = new Timeline(
                new KeyFrame(Duration.ZERO, new KeyValue(playButton.scaleXProperty(), 1)),
                new KeyFrame(Duration.seconds(0.5), new KeyValue(playButton.scaleXProperty(), 1.2)),
                new KeyFrame(Duration.seconds(1), new KeyValue(playButton.scaleXProperty(), 1))
        );
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();
    }

    private void addSong() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("MP3 files", "*.mp3"));
        File selectedFile = fileChooser.showOpenDialog(null);
        if (selectedFile != null) {
            playlist.add(selectedFile.toURI().toString());
            playlistView.getItems().add(selectedFile.getName());
        }
    }

    private void play() {
        if (!playlist.isEmpty()) {
            if (currentSongIndex == -1) {
                currentSongIndex = 0;
                String song = playlist.get(currentSongIndex);
                Media media = new Media(song);
                mediaPlayer = new MediaPlayer(media);
                mediaPlayer.setOnEndOfMedia(() -> {
                    currentSongIndex++;
                    if (currentSongIndex < playlist.size()) {
                        mediaPlayer.stop();
                        play();
                    } else {
                        stop();
                    }
                });
            }
            mediaPlayer.play();
        }
    }

    private void stop() {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            currentSongIndex = -1;
        }
    }

    private void setVolume(double value) {
        if (mediaPlayer != null) {
            mediaPlayer.setVolume(value / 100);
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
